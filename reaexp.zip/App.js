
import React,{ Component } from 'react'

import Register from './Matri/Register'
import  {BrowserRouter,Switch,Route} from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css';





 
 




const App =() => {
  return(

    <div>
   <BrowserRouter>
   <Switch>

         <Route exact path ="/register" component ={Register}/>


   </Switch>
  
   </BrowserRouter>
    </div>


  )
}



export default  App;
