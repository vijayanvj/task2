import React, { Component } from 'react'
import { useFormik } from 'formik'
import * as yup from 'yup';
import axios from 'axios';





const Registor = (props) => {
        const formik = useFormik({
            initialValues: {
                Name: '',
                email: '',
                Task: '',
                TaskDetails:'',
               

            },
            validationSchema: yup.object({
                Name: yup.string()
                    .strict()
                    .trim()
                    .required('this field required'),
                email: yup.string()
                    .email('enter the valied email')
                    .strict()
                    .trim()
                    .required('this field is required'),
                Task: yup.string()
                    .strict()
                    .trim()
                    .required('this field is required'),
                TaskDetails: yup.string()
                    .strict()
                    .trim()
                    .required('this field is required'),
               

            }),
            onSubmit: (data) => {
                console.log(data);
                axios.post('http://localhost:2009/api/register', data)
                
                  


            }
        });


      
   return (




    <div className = "container mt-2 " >
    <div className = "jumbotron" >
                <h4 > Employ Details  </h4> 
        <form autoComplete = "off"
                onSubmit = { formik.handleSubmit } >
                <div className = "form-group" >
                <label > Firstname: </label> <input type = "text"
                name = "Name"
                className = "form-control"
                onChange = { formik.handleChange }
                value = { formik.values.Name }/> {
                    formik.errors.Name ? <div className = "text-danger" > { formik.errors.Name } </div>  :null}
                    </div> 
                <div className = "form-group" >
                <label >Email </label> <input name = "email"
                className = "form-control"
                type = "text"
                onChange = { formik.handleChange }
                value = { formik.values.email }/> {
                    formik.errors.email ? <div className = "text-danger" > { formik.errors.email } </div> :null} 
                    </div> 
                    <div className = "form-group" >
                        <label> Task </label> <input name = "Task"
                    className = "form-control"
                    type = "text"
                    onChange = { formik.handleChange }
                    value = { formik.values.Task} /> {
                        formik.errors.Task ? <div className = "text-danger" > { formik.errors.Task } </div> :null}
                         </div> 
                           <div className = "form-group" >
                        <label> TaskDetails </label> <input name = "TaskDetails"
                    className = "form-control"
                    type = "text"
                    onChange = { formik.handleChange }
                    value = { formik.values.TaskDetails} /> {
                        formik.errors.TaskDetails ? <div className = "text-danger" > { formik.errors.TaskDetails } </div> :null}
                         </div> 
                         <div className = "d-flex justify-content-between" >
                           <button className = "btn btn-primary"
                             type = "submit" > submit </button> 
                         </div>
                         

             </form>
             
         </div>
                                       
 </div>

  


                                    )

                            }


                         export default Registor;