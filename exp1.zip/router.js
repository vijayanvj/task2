const express = require('express');
const router = express.Router();
const User = require('./userSchema');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');


router.post('/register', async(req, res) => { 
        const user = new User({
            Name: req.body.Name,
            email: req.body.email,
            Task: req.body.Task,
            TaskDetails:req.body.TaskDetails
           
        });

        var data = await user.save();
        res.json(data);

    } 
)
   





module.exports = router;